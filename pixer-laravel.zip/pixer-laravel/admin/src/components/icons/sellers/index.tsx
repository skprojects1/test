export { StoreIcon } from '@/components/icons/sellers/store';
export { BullsEyeIcon } from '@/components/icons/sellers/bullseye';
export { ChatIcon } from '@/components/icons/sellers/chat';
export { ReceiptIcon } from '@/components/icons/sellers/receipt';
export { RegisteredDocumentIcon } from '@/components/icons/sellers/registered-document';
export { ShoppingBagIcon } from '@/components/icons/sellers/shopping-bag';
