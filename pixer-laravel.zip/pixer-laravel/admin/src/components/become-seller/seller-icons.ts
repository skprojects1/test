export const sellerIconList = [
  {
    value: 'StoreIcon',
    label: 'Store',
  },
  {
    value: 'BullsEyeIcon',
    label: 'Bulls Eye',
  },
  {
    value: 'ChatIcon',
    label: 'Cart',
  },
  {
    value: 'ReceiptIcon',
    label: 'Receipt',
  },
  {
    value: 'RegisteredDocumentIcon',
    label: 'Registered Document',
  },
  {
    value: 'ShoppingBagIcon',
    label: 'Shopping Bag',
  },
];
