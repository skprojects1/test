export const typeIconList = [
  {
    value: 'FixedIcon',
    label: 'Fixed',
  },
  {
    value: 'LiquidIcon',
    label: 'Liquid',
  },
  {
    value: 'ResponsiveIcon',
    label: 'Responsive',
  },
  {
    value: 'NoTypeIcon',
    label: 'N/A',
  },
  // {
  //   value: 'BabyCare',
  //   label: 'Baby Care',
  // },
  // {
  //   value: 'Gadgets',
  //   label: 'Gadgets',
  // },
  // {
  //   value: 'Plant',
  //   label: 'Plant',
  // },
  // {
  //   value: 'HomeAppliance',
  //   label: 'Home Appliance',
  // },
  // {
  //   value: 'MicroGreens',
  //   label: 'Micro Greens',
  // },
];
